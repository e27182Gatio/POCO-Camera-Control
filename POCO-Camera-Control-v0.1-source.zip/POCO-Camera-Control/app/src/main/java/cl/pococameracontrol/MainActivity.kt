package cl.pococameracontrol

import android.Manifest
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.os.SystemClock
import android.view.ViewConfiguration
import android.provider.MediaStore
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.core.Camera
import androidx.camera.core.CameraInfo
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.core.DynamicRange
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.text.SimpleDateFormat
import java.util.Locale
import kotlin.math.max

/**
 * Prototipo foreground-only: los píxeles son negros, pero la pantalla y su táctil
 * siguen encendidos. No funciona con el teléfono físicamente suspendido.
 */
class MainActivity : ComponentActivity() {

    private enum class CaptureMode { PHOTO, VIDEO }
    private data class CameraTarget(
        val selector: CameraSelector,
        val info: CameraInfo,
        val displayName: String,
        val physicalId: String? = null
    )

    private var mode = CaptureMode.PHOTO
    private var selectedAngle = "0.6×"
    private var inBlackMode = false
    private var preparing = false
    private var takingPhoto = false
    private var stoppingVideo = false
    private var exitWhenSaved = false
    private var lastDoubleTapAt = 0L
    private var provider: ProcessCameraProvider? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var blackSurface: View? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val cameraGranted = grants[Manifest.permission.CAMERA] == true
        val audioGranted = grants[Manifest.permission.RECORD_AUDIO] == true
        if (cameraGranted && audioGranted) {
            enterBlackMode()
        } else {
            message("Se necesitan permisos de cámara y micrófono para el modo completo")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun showHome() {
        inBlackMode = false
        preparing = false
        exitWhenSaved = false
        takingPhoto = false
        stoppingVideo = false
        imageCapture = null
        videoCapture = null
        blackSurface = null
        provider?.unbindAll()
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.attributes = window.attributes.apply { screenBrightness = -1f }
        WindowInsetsControllerCompat(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
        WindowCompat.setDecorFitsSystemWindows(window, true)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(36), dp(24), dp(22))
            setBackgroundColor(Color.rgb(16, 20, 28))
        }
        fun label(text: String, size: Float = 16f): TextView = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.WHITE)
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(label("POCO Camera Control", 25f))
        root.addView(label("Doble toque sobre una pantalla negra AMOLED. El panel táctil sigue encendido.", 15f))
        root.addView(label("Modo de captura", 19f))

        val modes = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val photo = RadioButton(this).apply { text = "Fotografía"; id = View.generateViewId() }
        val video = RadioButton(this).apply { text = "Video + audio"; id = View.generateViewId() }
        modes.addView(photo)
        modes.addView(video)
        modes.check(if (mode == CaptureMode.PHOTO) photo.id else video.id)
        modes.setOnCheckedChangeListener { _, id ->
            mode = if (id == photo.id) CaptureMode.PHOTO else CaptureMode.VIDEO
        }
        root.addView(modes)

        root.addView(label("Ángulo inicial preferido", 19f))
        val angles = arrayOf("0.6×", "1×", "2×")
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, angles)
            setSelection(angles.indexOf(selectedAngle).coerceAtLeast(0))
        }
        root.addView(spinner)
        root.addView(label("Video: preferir 2160p (4K); si no está disponible, usar 1080p/720p. Audio activado.", 14f))

        root.addView(Button(this).apply {
            text = "INICIAR PANTALLA NEGRA"
            setOnClickListener {
                selectedAngle = angles[spinner.selectedItemPosition]
                requestStart()
            }
        })
        root.addView(label("En la pantalla negra: doble toque = foto o iniciar/detener video. Mantener pulsado 2 s = salir.", 14f))
        root.addView(label("Aviso: grabación visible para Android, sin servicio oculto y sin acceso a internet. Si se bloquea físicamente el teléfono, esta sesión termina.", 13f))
        setContentView(root)
    }

    private fun requestStart() {
        val needed = listOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) enterBlackMode()
        else permissionLauncher.launch(missing.toTypedArray())
    }

    private fun enterBlackMode() {
        inBlackMode = true
        preparing = true
        exitWhenSaved = false
        takingPhoto = false
        stoppingVideo = false
        recording = null
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.attributes = window.attributes.apply { screenBrightness = 0.01f }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }

        val frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        frame.addView(previewView, FrameLayout.LayoutParams(-1, -1))
        val overlay = View(this).apply { setBackgroundColor(Color.BLACK) }
        blackSurface = overlay
        frame.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (!inBlackMode || preparing || exitWhenSaved) return true
                val now = SystemClock.elapsedRealtime()
                if (now - lastDoubleTapAt < 550L) return true // antibounce/triple-tap
                lastDoubleTapAt = now
                onCaptureGesture()
                return true
            }
        })
        // GestureDetector's long-press timeout is ~500 ms, not the requested 2 seconds.
        val exitHold = Runnable { if (inBlackMode) requestExit() }
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var firstX = 0f
        var firstY = 0f
        overlay.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    firstX = event.x
                    firstY = event.y
                    overlay.postDelayed(exitHold, 2_000L)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL,
                MotionEvent.ACTION_POINTER_DOWN -> overlay.removeCallbacks(exitHold)
                MotionEvent.ACTION_MOVE -> {
                    if (kotlin.math.abs(event.x - firstX) > touchSlop ||
                        kotlin.math.abs(event.y - firstY) > touchSlop) {
                        overlay.removeCallbacks(exitHold)
                    }
                }
            }
            detector.onTouchEvent(event)
            true
        }
        setContentView(frame)
        message("Iniciando cámara. Doble toque: capturar. Mantén pulsado: salir.")
        initCamera(previewView)
    }

    private fun initCamera(view: PreviewView) {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            if (!inBlackMode) return@addListener
            try {
                provider = future.get()
                val target = selectCamera(provider!!)
                if (target == null) {
                    unavailableUltraWide("La cámara ultra gran angular 0.6× no está expuesta a esta aplicación en HyperOS.")
                    return@addListener
                }
                bindCamera(view, target)
            } catch (e: Exception) {
                fail("No se pudo abrir la cámara: ${e.message}")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun selectCamera(cameraProvider: ProcessCameraProvider): CameraTarget? {
        val backs = cameraProvider.availableCameraInfos.filter {
            it.lensFacing == CameraSelector.LENS_FACING_BACK
        }
        val logical = CameraSelector.DEFAULT_BACK_CAMERA.filter(backs).firstOrNull()
            ?: return null
        val logicalId = Camera2CameraInfo.from(logical).cameraId
        val regular = CameraTarget(CameraSelector.DEFAULT_BACK_CAMERA, logical, "1×")
        if (selectedAngle == "1×" || selectedAngle == "2×") return regular

        val manager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val baseline = viewRatio(manager.getCameraCharacteristics(logicalId)) ?: return null

        // Primero buscar un sensor trasero realmente accesible como cámara independiente.
        val direct = backs.mapNotNull { info ->
            val id = Camera2CameraInfo.from(info).cameraId
            val fov = try { viewRatio(manager.getCameraCharacteristics(id)) } catch (_: Exception) { null }
            if (id == logicalId || fov == null || fov < baseline * 1.25f) null
            else Triple(id, fov, info)
        }.maxByOrNull { it.second }
        if (direct != null) {
            val cameraId = direct.first
            val selector = CameraSelector.Builder()
                .requireLensFacing(CameraSelector.LENS_FACING_BACK)
                .addCameraFilter { infos ->
                    infos.filter { Camera2CameraInfo.from(it).cameraId == cameraId }
                }.build()
            return CameraTarget(selector, direct.third, "0.6× (gran angular detectada)")
        }

        // En cámaras lógicas multicámara, intentar seleccionar su sensor físico ultra gran angular.
        val logicalCharacteristics = manager.getCameraCharacteristics(logicalId)
        val physical = logicalCharacteristics.physicalCameraIds.mapNotNull { id ->
            val fov = try { viewRatio(manager.getCameraCharacteristics(id)) } catch (_: Exception) { null }
            if (fov != null && fov >= baseline * 1.25f) Pair(id, fov) else null
        }.maxByOrNull { it.second }
        if (physical != null) {
            val selector = CameraSelector.Builder()
                .requireLensFacing(CameraSelector.LENS_FACING_BACK)
                .addCameraFilter { infos ->
                    infos.filter { Camera2CameraInfo.from(it).cameraId == logicalId }
                }
                .setPhysicalCameraId(physical.first)
                .build()
            return CameraTarget(selector, logical, "0.6× (sensor físico solicitado)", physical.first)
        }
        return null
    }

    /** Aproximación relativa al campo horizontal de visión: ancho del sensor / distancia focal. */
    private fun viewRatio(c: CameraCharacteristics): Float? {
        val sensor = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE) ?: return null
        val focal = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
            ?.filter { it > 0f }?.minOrNull() ?: return null
        return sensor.width / max(focal, 0.01f)
    }

    private fun bindCamera(view: PreviewView, target: CameraTarget) {
        val cameraProvider = provider ?: return
        cameraProvider.unbindAll()
        val preview = Preview.Builder().build().apply {
            setSurfaceProvider(view.surfaceProvider)
        }
        try {
            val camera: Camera
            if (mode == CaptureMode.PHOTO) {
                val photoCase = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()
                imageCapture = photoCase
                camera = cameraProvider.bindToLifecycle(this, target.selector, preview, photoCase)
                videoCapture = null
            } else {
                val qualities = Recorder.getVideoCapabilities(target.info)
                    .getSupportedQualities(DynamicRange.SDR)
                val order = listOf(Quality.UHD, Quality.FHD, Quality.HD, Quality.SD)
                val chosen = order.firstOrNull { qualities.contains(it) }
                    ?: throw IllegalStateException("No hay calidad de video compatible")
                val recorder = Recorder.Builder()
                    .setQualitySelector(QualitySelector.from(chosen))
                    .build()
                val videoCase = VideoCapture.withOutput(recorder)
                videoCapture = videoCase
                camera = cameraProvider.bindToLifecycle(this, target.selector, preview, videoCase)
                imageCapture = null
                val qualityName = when (chosen) {
                    Quality.UHD -> "4K (2160p)"
                    Quality.FHD -> "1080p"
                    Quality.HD -> "720p"
                    else -> "SD"
                }
                message("Video: $qualityName · ${target.displayName} · audio activado")
            }
            var activeLabel = target.displayName
            if (selectedAngle == "2×") {
                val maximum = camera.cameraInfo.zoomState.value?.maxZoomRatio ?: 1f
                if (maximum >= 2f) {
                    camera.cameraControl.setZoomRatio(2f)
                    activeLabel = "2× (zoom)"
                } else message("Este sensor no admite ampliación de 2×; se utiliza 1×")
            }
            preparing = false
            message("Cámara lista: $activeLabel")
        } catch (e: Exception) {
            cameraProvider.unbindAll()
            if (selectedAngle == "0.6×") {
                unavailableUltraWide("Este firmware rechaza el uso de 0.6× en el modo solicitado: ${e.message}")
            } else fail("No se pudo iniciar la captura: ${e.message}")
        }
    }

    private fun unavailableUltraWide(details: String) {
        // Nunca cambiar silenciosamente al lente 1×.
        leaveBlackMode()
        AlertDialog.Builder(this)
            .setTitle("0.6× no disponible")
            .setMessage("$details\n\n¿Quieres entrar al modo negro usando 1×?")
            .setPositiveButton("Usar 1×") { _, _ ->
                selectedAngle = "1×"
                enterBlackMode()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun onCaptureGesture() {
        if (mode == CaptureMode.PHOTO) {
            capturePhoto()
        } else if (recording == null) {
            startVideo()
        } else {
            stopVideo()
        }
    }

    private fun capturePhoto() {
        if (takingPhoto) return
        val capture = imageCapture ?: return
        takingPhoto = true
        feedback()
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "PCC_${stamp()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/POCOCameraControl")
        }
        val output = ImageCapture.OutputFileOptions.Builder(
            contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
        ).build()
        capture.takePicture(output, ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                    takingPhoto = false
                    message("Fotografía guardada")
                    if (exitWhenSaved) leaveBlackMode()
                }
                override fun onError(exception: ImageCaptureException) {
                    takingPhoto = false
                    message("Error al guardar fotografía: ${exception.message}")
                    if (exitWhenSaved) leaveBlackMode()
                }
            })
    }

    private fun startVideo() {
        if (preparing || stoppingVideo || exitWhenSaved) return
        val capture = videoCapture ?: return
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "PCC_${stamp()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/POCOCameraControl")
        }
        val options = MediaStoreOutputOptions.Builder(
            contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()
        try {
            recording = capture.output.prepareRecording(this, options)
                .withAudioEnabled()
                .start(ContextCompat.getMainExecutor(this)) { event ->
                    when (event) {
                        is VideoRecordEvent.Start -> {
                            feedback()
                            message("Grabación iniciada · doble toque para detener")
                        }
                        is VideoRecordEvent.Finalize -> {
                            val failed = event.hasError()
                            recording = null
                            stoppingVideo = false
                            if (failed) message("Error al finalizar video: ${event.error}")
                            else message("Video guardado")
                            if (exitWhenSaved) leaveBlackMode()
                        }
                    }
                }
        } catch (e: Exception) {
            recording = null
            stoppingVideo = false
            message("No se pudo iniciar video: ${e.message}")
        }
    }

    private fun stopVideo() {
        if (stoppingVideo) return
        val active = recording ?: return
        stoppingVideo = true
        feedback()
        active.stop() // Finalize confirmará cuándo terminó de guardar el archivo.
    }

    private fun requestExit() {
        exitWhenSaved = true
        if (recording != null) stopVideo()
        else if (!takingPhoto) leaveBlackMode()
    }

    private fun leaveBlackMode() {
        if (!inBlackMode) return
        if (recording != null || takingPhoto) {
            requestExit()
            return
        }
        showHome()
    }

    private fun fail(reason: String) {
        leaveBlackMode()
        AlertDialog.Builder(this).setTitle("Error de cámara")
            .setMessage(reason).setPositiveButton("Aceptar", null).show()
    }

    private fun feedback() {
        blackSurface?.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
    }

    private fun message(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    private fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US)
        .format(System.currentTimeMillis())

    override fun onStop() {
        super.onStop()
        // Si el teléfono se bloquea realmente, la interfaz táctil no sigue funcionando.
        // Detener la sesión para no seguir grabando sin una interfaz de control visible.
        if (inBlackMode) requestExit()
    }

    override fun onDestroy() {
        if (recording != null) {
            try { recording?.stop() } catch (_: Exception) { /* best effort */ }
        }
        provider?.unbindAll()
        super.onDestroy()
    }
}
