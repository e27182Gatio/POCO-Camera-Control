# POCO Camera Control — V0.1 (prototipo Android)

Aplicación nativa Kotlin + CameraX para **POCO X7 Pro / Android 16**, diseñada para una sesión fotográfica o de video **con pantalla negra AMOLED y táctil activo**.

> **Importante:** no apaga físicamente la pantalla. La pantalla sigue encendida para poder detectar el doble toque. No puede detectar toques si pulsas el botón de encendido y Android suspende el panel.

## Funciones

- Modo **Foto**: doble toque toma una fotografía JPEG.
- Modo **Video**: doble toque inicia; otro doble toque detiene y guarda un video con audio.
- **Mantener pulsado 2 segundos:** salir de la pantalla negra; si está grabando, solicita detener y espera el evento de finalización.
- **0.6× preferido**: intenta detectar una cámara trasera ultra gran angular independiente o una cámara física de un grupo lógico usando Camera2/CameraX. Si no existe acceso, **pregunta antes de cambiar a 1×**.
- **1×** cámara trasera predeterminada y **2×** zoom cuando el firmware lo admita.
- **4K 2160p** prioritario, con degradación a 1080p, 720p o SD en función de las calidades reportadas por CameraX.
- Grabación de audio habilitada con el permiso de micrófono.
- Guarda archivos mediante MediaStore en `Pictures/POCOCameraControl` y `Movies/POCOCameraControl`.
- No solicita Internet, no utiliza root, ni implementa grabación persistente oculta.

## Compilar

### Android Studio

1. Descomprime el proyecto y abre la carpeta `POCO-Camera-Control` en Android Studio.
2. Instala Android SDK Platform 36 cuando Android Studio lo solicite y usa JDK 17.
3. Sincroniza Gradle (Android Gradle Plugin 8.13.2, Kotlin 2.2.21, CameraX 1.5.3).
4. Conecta el POCO X7 Pro y elige **Run**; o utiliza **Build > Build APK(s)**.
5. Concede acceso a cámara y micrófono; elige modo y ángulo y toca **INICIAR PANTALLA NEGRA**.

### GitHub Actions

1. Crea un repositorio **nuevo** de GitHub para este proyecto.
2. Sube **el contenido** de esta carpeta a la raíz del repositorio (incluida `.github/workflows/android-debug.yml`).
3. Desde **Actions > Construir APK Android (debug) > Run workflow**, inicia la compilación; en `main` también se ejecuta tras cada `push`.
4. Cuando la ejecución termine correctamente, descarga el artefacto **POCO-Camera-Control-debug-APK** y extrae el APK. Instálalo únicamente si confías en la procedencia del archivo.

La versión **debug** es para pruebas, no para publicar en Play Store. El APK se genera con la firma de depuración de la máquina de compilación y no es una firma de lanzamiento estable.

## Pruebas esenciales en HyperOS

- Doble toque: una sola foto por gesto.
- Segundo doble toque: detener grabación y comprobar MP4 + audio.
- Comprobar que 0.6× realmente modifica el campo de visión comparándolo con la app Xiaomi Camera.
- Comprobar resolución real del video en detalles del archivo, **no** inferirla de la configuración anunciada.
- Bloquear el teléfono con encendido: debe detener la sesión; el doble toque físico ya no funcionará.
- Probar cambios de orientación, llamadas entrantes, falta de espacio, revocación de permisos y cierre forzado.
- Confirmar que las imágenes y videos aparecen en la galería.

## Limitaciones técnicas conocidas

- La API de cámara de terceros puede **no exponer 0.6×** o puede negar a terceros 4K en la cámara ultra gran angular.
- En una cámara lógica que anuncia 4K, algunos sensores físicos pueden admitir menos resoluciones; el firmware puede rechazar la grabación aunque CameraX reporte 4K. La app muestra el error: no inventa capacidades.
- Los archivos iniciados y luego interrumpidos abruptamente por el sistema podrían fallar en finalizar.
- No hay servicio de primer plano: intencionadamente solo captura mientras la Activity está visible. Al bloquear/abandonar la app, termina la sesión.
- No existe previsualización visible en modo negro; encuadrar requiere pruebas y referencias externas.
- Este proyecto es un **prototipo no compilado ni probado en el POCO** durante su creación. Las APIs y los ajustes HyperOS se deben validar con un APK real.

## Privacidad y uso responsable

La cámara y el micrófono son recursos sensibles. Activa la sesión conscientemente, respeta los indicadores de privacidad de Android e informa y pide consentimiento cuando corresponda antes de grabar a otras personas. La aplicación no intenta ocultar los indicadores del sistema ni saltarse el bloqueo del teléfono.

## Referencias

- [CameraX Video Capture](https://developer.android.com/media/camera/camerax/video-capture)
- [CameraX CameraSelector.Builder#setPhysicalCameraId](https://developer.android.com/reference/androidx/camera/core/CameraSelector.Builder)
- [Android: Keep the screen on](https://developer.android.com/develop/background-work/background-tasks/awake/screen-on)
- [POCO X7 Pro especificaciones](https://www.mi.com/global/product/poco-x7-pro/specs/)

## Licencia

MIT. Consulta `LICENSE`.
